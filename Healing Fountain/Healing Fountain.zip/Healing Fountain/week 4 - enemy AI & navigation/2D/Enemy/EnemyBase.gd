## Base class untuk logika dasar musuh.
##
## Mengelola inisialisasi group, kematian, dan delegasi rotasi senjata berdasarkan velocity.
class_name EnemyBase
extends CharacterBody2D

## Kecepatan jalan musuh.
@export var speed: float = 1.0 
## Referensi ke komponen senjata musuh.
@export var weapon: WeaponComponent = null
## Referensi ke komponen kesehatan musuh.
@export var health_component: EnemyHealthComponent = null

## Referensi ke NavigationAgent2D untuk pathfinding.
@export var nav_agent: NavigationAgent2D = null

var player: Node2D

func _ready() -> void:
	player = get_tree().get_first_node_in_group("player")

	if health_component:
		health_component.died.connect(_on_died)

func _physics_process(delta: float) -> void:
	if player:
		var direction = (player.global_position - global_position)
		
		# 🔥 ini yang bikin lambat
		velocity = direction.normalized() * speed

	# rotasi senjata
	if velocity.length() > 0 and weapon:
		weapon.update_rotation(velocity.normalized(), delta)

	move_and_slide()

## Mendelegasikan penerimaan damage ke HealthComponent.
func take_damage(amount: float) -> void:
	if health_component:
		health_component.take_damage(amount)

## Menghapus musuh dari scene saat mati.
func _on_died() -> void:
	queue_free()
