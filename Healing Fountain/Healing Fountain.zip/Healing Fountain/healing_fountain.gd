extends Area2D

@export var heal_per_second: float = 20.0

var player_inside = null

func _ready():
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)

func _process(delta):
	if player_inside != null:
		if player_inside.health_component != null:
			player_inside.health_component.heal(
				heal_per_second * delta
			)

func _on_body_entered(body):
	print("TERDETEKSI:", body.name)

	if body.is_in_group("Player"):
		player_inside = body

func _on_body_exited(body):
	if body == player_inside:
		player_inside = null
