extends Area2D

@export var break_time: float = 1.5
@export var cracked_texture: Texture2D
@onready var timer = $BreakTimer
@onready var floor_collision = $StaticBody2D/CollisionShape2D
@onready var sprite = $Sprite2D

var triggered := false

func _ready() -> void:
	timer.wait_time = break_time

func _on_body_entered(body: Node2D) -> void:
	if body is Player and !triggered:
		triggered = true
		
		# ganti sprite jadi retak
		sprite.texture = cracked_texture
		
		timer.start()
	if body is Player and !triggered:
		triggered = true
		timer.start()

func _on_break_timer_timeout() -> void:
	
	# Hilangkan collision
	floor_collision.disabled = true
	
	# Hilangkan visual
	sprite.visible = false
