extends CanvasLayer

@onready var damage_flash = $Control/DamageFlash

func flash_damage():
	damage_flash.color = Color(1, 0, 0, 0.5)

	var tween = create_tween()
	tween.tween_property(
		damage_flash,
		"color",
		Color(1, 0, 0, 0),
		0.15
	)
