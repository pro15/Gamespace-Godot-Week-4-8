extends ColorRect

func flash_damage():
	color = Color(1, 0, 0, 0.5)

	var tween = create_tween()
	tween.tween_property(
		self,
		"color",
		Color(1, 0, 0, 0),
		0.15
	)
