class_name Player
extends CharacterBody2D

@export var jump_force: float = -500
@export var speed: float = 200

var friction: float = 20
var accelerate: float = 50
var dir: float = 0.0

# DASH
@export var dash_speed: float = 4000
@export var dash_duration: float = 0.03
@export var dash_cooldown: float = 1.0

var can_dash := true
var is_dashing := false

@onready var animation: AnimatedSprite2D = $AnimatedSprite2D
@onready var compass = $CanvasLayer/Compass

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	# Animation
	if Input.is_action_just_pressed("jump") and not is_on_floor():
		animation.play("Jump")
	elif is_on_floor():
		if dir != 0:
			animation.play("Walk")
		else:
			animation.play("Idle")
	
	facing_direction()
	update_compass()

func _physics_process(delta: float) -> void:
	
	# Gravity
	if not is_on_floor() and !is_dashing:
		velocity += get_gravity() * delta
	
	# Jump
	if Input.is_action_just_pressed("new_jump") and is_on_floor():
		velocity.y = jump_force
	
	# Movement
	dir = Input.get_axis("new_left", "new_right")
	
	# Disable movement while dashing
	if !is_dashing:
		if dir != 0:
			velocity.x = move_toward(
				velocity.x,
				dir * speed,
				accelerate
			)
		else:
			velocity.x = move_toward(
				velocity.x,
				0,
				friction
			)
	
	# DASH
	if Input.is_action_just_pressed("dash") and can_dash:
		dash()
	
	move_and_slide()

func facing_direction() -> void:
	if dir < 0:
		animation.flip_h = true
	elif dir > 0:
		animation.flip_h = false

func dash() -> void:
	can_dash = false
	is_dashing = true
	
	var dash_direction = 1
	
	if animation.flip_h:
		dash_direction = -1
	
	# Blink effect
	animation.modulate.a = 0.5
	
	velocity.x = dash_speed * dash_direction
	
	await get_tree().create_timer(dash_duration).timeout
	
	velocity.x = 0
	
	animation.modulate.a = 1.0
	
	is_dashing = false
	
	await get_tree().create_timer(dash_cooldown).timeout
	
	can_dash = true

func update_compass() -> void:
	if dir > 0:
		compass.text = "EAST →"
	elif dir < 0:
		compass.text = "← WEST"
	else:
		compass.text = "•"
